package com.whatsdail.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_PHONE_CONTACT = 41;
    private static final String[] KEYS = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
    private static final int GREEN = Color.rgb(23, 119, 77);
    private static final int DARK = Color.rgb(25, 52, 41);
    private static final int MUTED = Color.rgb(112, 130, 119);
    private static final int LINE = Color.rgb(229, 237, 231);
    private static final int PALE = Color.rgb(248, 251, 249);
    private SharedPreferences contacts;
    private String pendingKey;
    private LinearLayout root;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        contacts = getSharedPreferences("speed-dial-contacts", MODE_PRIVATE);
        Window window = getWindow();
        window.setStatusBarColor(Color.WHITE);
        window.setNavigationBarColor(Color.WHITE);
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        showDialpad();
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable shape(int color, int radius, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        if (strokeColor != 0) drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private View touchSurface(int fill, int radius, int stroke) {
        return new View(this) {{
            setBackground(new RippleDrawable(ColorStateList.valueOf(Color.rgb(222, 239, 228)), shape(fill, radius, stroke), null));
        }};
    }

    private void prepareScreen(String title, boolean showBack) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(dp(20), dp(8), dp(20), dp(10));
        setContentView(root);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, 0, 0, dp(4));
        if (showBack) {
            TextView back = text("‹", 32, GREEN, false);
            back.setGravity(Gravity.CENTER);
            back.setContentDescription("Back to dialpad");
            back.setOnClickListener(v -> showDialpad());
            bar.addView(back, new LinearLayout.LayoutParams(dp(42), dp(48)));
        } else {
            TextView mark = text("☎", 21, GREEN, true);
            mark.setGravity(Gravity.CENTER);
            mark.setBackground(shape(Color.rgb(231, 245, 236), 15, 0));
            LinearLayout.LayoutParams markLp = new LinearLayout.LayoutParams(dp(42), dp(42));
            markLp.rightMargin = dp(12);
            bar.addView(mark, markLp);
        }

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = text(showBack ? title : "What's Dail", 18, DARK, true);
        brand.addView(heading);
        if (!showBack) {
            TextView sub = text("Your favorite people, closer", 11, MUTED, false);
            brand.addView(sub);
        }
        bar.addView(brand, new LinearLayout.LayoutParams(0, dp(50), 1));

        if (!showBack) {
            TextView settings = text("⚙", 19, DARK, false);
            settings.setGravity(Gravity.CENTER);
            settings.setContentDescription("Settings");
            settings.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.rgb(236, 243, 238)), shape(Color.WHITE, 14, LINE), null));
            settings.setOnClickListener(v -> showSettings());
            bar.addView(settings, new LinearLayout.LayoutParams(dp(42), dp(42)));
        }
        root.addView(bar);
    }

    private void showDialpad() {
        prepareScreen("What's Dail", false);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(16), 0, dp(4));
        scroll.addView(content);

        TextView eyebrow = text("S P E E D   D I A L", 10, GREEN, true);
        content.addView(eyebrow);
        TextView title = text("Who would you like\nto talk to?", 27, DARK, true);
        title.setLetterSpacing(-0.035f);
        title.setPadding(0, dp(8), 0, dp(6));
        content.addView(title);
        content.addView(text("Hold a contact to continue in WhatsApp.", 13, MUTED, false));

        GridLayout pad = new GridLayout(this);
        pad.setColumnCount(3);
        pad.setUseDefaultMargins(false);
        LinearLayout.LayoutParams padLp = new LinearLayout.LayoutParams(-1, -2);
        padLp.setMargins(-dp(5), dp(17), -dp(5), 0);
        for (String key : KEYS) {
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            String savedName = contacts.getString(key + "_name", "");
            boolean assigned = !savedName.isEmpty() && !contacts.getString(key + "_phone", "").isEmpty();
            cell.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.rgb(226, 241, 231)), shape(PALE, 19, LINE), null));
            TextView number = text(key, 25, GREEN, true);
            number.setGravity(Gravity.CENTER);
            TextView name = text(assigned ? savedName : "Add contact", 11, assigned ? MUTED : Color.rgb(159, 173, 164), false);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(1);
            name.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(-1, -2);
            nameLp.setMargins(dp(4), dp(4), dp(4), 0);
            cell.addView(number);
            cell.addView(name, nameLp);
            cell.setContentDescription(assigned ? key + ", " + savedName + ". Long press to open WhatsApp." : key + ", add contact.");
            cell.setOnClickListener(v -> { if (!assigned) editContact(key); });
            cell.setOnLongClickListener(v -> { openWhatsApp(key); return true; });
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.height = dp(80);
            lp.columnSpec = key.equals("0") ? GridLayout.spec(1, 1f) : GridLayout.spec(GridLayout.UNDEFINED, 1f);
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            pad.addView(cell, lp);
        }
        content.addView(pad, padLp);

        LinearLayout tip = new LinearLayout(this);
        tip.setGravity(Gravity.CENTER_VERTICAL);
        tip.setPadding(dp(13), dp(11), dp(13), dp(11));
        tip.setBackground(shape(Color.rgb(239, 247, 241), 15, 0));
        TextView tipIcon = text("⌁", 20, GREEN, true);
        tipIcon.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tipIconLp = new LinearLayout.LayoutParams(dp(25), -2);
        tipIconLp.rightMargin = dp(8);
        tip.addView(tipIcon, tipIconLp);
        LinearLayout tipCopy = new LinearLayout(this);
        tipCopy.setOrientation(LinearLayout.VERTICAL);
        tipCopy.addView(text("Quick and simple", 12, DARK, true));
        tipCopy.addView(text("Hold a number to open its WhatsApp chat.", 11, MUTED, false));
        tip.addView(tipCopy);
        LinearLayout.LayoutParams tipLp = new LinearLayout.LayoutParams(-1, -2);
        tipLp.topMargin = dp(10);
        content.addView(tip, tipLp);

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setPadding(0, dp(10), 0, 0);
        TextView privacy = text("Contacts stay on this device", 10, MUTED, false);
        footer.addView(privacy, new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = text("Private by design", 10, GREEN, true);
        badge.setPadding(dp(9), dp(6), dp(9), dp(6));
        badge.setBackground(shape(Color.rgb(239, 248, 242), 30, 0));
        footer.addView(badge);
        content.addView(footer);

        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void showSettings() {
        prepareScreen("Speed dial contacts", true);
        TextView intro = text("Add a name and WhatsApp number to each key. Include your country code.", 13, MUTED, false);
        intro.setPadding(dp(2), dp(8), dp(2), dp(14));
        root.addView(intro);

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (String key : KEYS) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(11), dp(12), dp(11));
            row.setBackground(shape(PALE, 16, LINE));
            TextView number = text(key, 17, GREEN, true);
            number.setGravity(Gravity.CENTER);
            number.setBackground(shape(Color.rgb(232, 245, 236), 10, 0));
            row.addView(number, new LinearLayout.LayoutParams(dp(35), dp(35)));

            LinearLayout detail = new LinearLayout(this);
            detail.setOrientation(LinearLayout.VERTICAL);
            detail.setPadding(dp(11), 0, dp(5), 0);
            String savedName = contacts.getString(key + "_name", "");
            String savedPhone = contacts.getString(key + "_phone", "");
            detail.addView(text(savedName.isEmpty() ? "Not assigned" : savedName, 14, DARK, true));
            TextView phone = text(savedPhone.isEmpty() ? "Tap to add a number" : savedPhone, 11, MUTED, false);
            phone.setMaxLines(1);
            phone.setEllipsize(TextUtils.TruncateAt.END);
            detail.addView(phone);
            row.addView(detail, new LinearLayout.LayoutParams(0, -2, 1));
            TextView edit = text(savedPhone.isEmpty() ? "+" : "Edit", 13, GREEN, true);
            edit.setGravity(Gravity.CENTER);
            row.addView(edit, new LinearLayout.LayoutParams(dp(42), dp(38)));
            row.setOnClickListener(v -> editContact(key));
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
            rowLp.bottomMargin = dp(8);
            list.addView(row, rowLp);
        }
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void editContact(String key) {
        pendingKey = key;
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), 0, dp(18), 0);
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("Contact name");
        name.setText(contacts.getString(key + "_name", ""));
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText phone = new EditText(this);
        phone.setSingleLine(true);
        phone.setHint("WhatsApp number with country code");
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        phone.setText(contacts.getString(key + "_phone", ""));
        Button pick = new Button(this);
        pick.setText("Choose from phone contacts");
        form.addView(name);
        form.addView(phone);
        form.addView(pick);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Set up key " + key)
                .setView(form)
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Remove", (d, which) -> {
                    contacts.edit().remove(key + "_name").remove(key + "_phone").apply();
                    showSettings();
                })
                .setPositiveButton("Save", null)
                .create();
        pick.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            startActivityForResult(intent, PICK_PHONE_CONTACT);
            dialog.dismiss();
        });
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String value = phone.getText().toString().trim();
            String displayName = name.getText().toString().trim();
            String digits = value.replaceAll("[^0-9]", "");
            if (digits.length() < 7) {
                phone.setError("Enter a complete number with country code");
                return;
            }
            if (displayName.isEmpty()) displayName = value;
            contacts.edit().putString(key + "_name", displayName).putString(key + "_phone", value).apply();
            dialog.dismiss();
            showSettings();
        }));
        dialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PHONE_CONTACT && resultCode == RESULT_OK && data != null && pendingKey != null) {
            try (Cursor cursor = getContentResolver().query(data.getData(), new String[]{
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
            }, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    contacts.edit()
                            .putString(pendingKey + "_name", cursor.getString(0))
                            .putString(pendingKey + "_phone", cursor.getString(1))
                            .apply();
                }
            } catch (Exception ignored) { }
        }
        if (pendingKey != null) showSettings();
    }

    private void openWhatsApp(String key) {
        String raw = contacts.getString(key + "_phone", "");
        String number = raw.replaceAll("[^0-9]", "");
        if (number.length() < 7) {
            Toast.makeText(this, "Assign a contact to " + key + " first", Toast.LENGTH_SHORT).show();
            return;
        }
        Uri chat = Uri.parse("https://wa.me/" + number);
        Intent whatsapp = new Intent(Intent.ACTION_VIEW, chat);
        whatsapp.setPackage("com.whatsapp");
        try {
            startActivity(whatsapp);
        } catch (Exception notInstalled) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, chat));
            } catch (Exception noHandler) {
                Toast.makeText(this, "Could not open WhatsApp for this number", Toast.LENGTH_LONG).show();
            }
        }
    }
}
